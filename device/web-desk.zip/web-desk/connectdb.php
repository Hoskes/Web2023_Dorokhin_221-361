<?php
$connect = mysqli_connect("localhost", "root", "root", "desk");
//mysqli_set_charset($connect, "utf8");
?>