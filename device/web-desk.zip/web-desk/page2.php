<?php
$title = "Заголовок страницы 2";
$content = "Содержимое страницы 2.";
require("template.php");
?>