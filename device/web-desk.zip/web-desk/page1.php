<?php
$title = "Заголовок страницы 1";
$content = "Содержимое страницы 1.";
require("template.php");
?>