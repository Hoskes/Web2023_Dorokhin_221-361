<?php
if(!$session_user){
	echo "Необходимо авторизоваться.";
	
}
?>