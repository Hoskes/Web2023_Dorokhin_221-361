
    <footer>
        <p>Контакты: </p>
        <p>Телефон: +7(968)741-51-35</p>
        <p>E-mail: a.n.dorokhin@mail.ru</p>
        <p>Собрано: <?php $currentTime = date("d.m.Y в H:i:s"); echo $currentTime; ?></p>
    </footer>
</body>

</html>